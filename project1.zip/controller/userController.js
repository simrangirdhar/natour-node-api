const getAllusers = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'error is function',
  });
};
const createNewUser = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'error is function',
  });
};
const getUserById = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'error is function',
  });
};
const updateUserById = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'error is function',
  });
};
const deleteUserById = (req, res) => {
  res.status(500).json({
    status: 'error',
    message: 'error is function',
  });
};

module.exports = {
  getAllusers,
  createNewUser,
  getUserById,
  updateUserById,
  deleteUserById,
};
